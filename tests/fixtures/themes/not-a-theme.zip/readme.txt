just words
